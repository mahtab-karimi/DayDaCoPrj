USE [dbWebTag]
GO

/****** Object:  Table [dbo].[tblTruckType]    Script Date: 10/19/2019 10:42:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tblTruckType](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[title] [varchar](500) NULL,
	[deleted] [int] NULL,
 CONSTRAINT [PK_tblTruckType] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[tblTruckType] ADD  CONSTRAINT [DF_tblTruckType_deleted]  DEFAULT ((0)) FOR [deleted]
GO

