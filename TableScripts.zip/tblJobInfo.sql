USE [dbWebTag]
GO

/****** Object:  Table [dbo].[tblJobInfo]    Script Date: 10/19/2019 10:43:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tblJobInfo](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[jobDate] [datetime2](7) NULL,
	[jobDay] [int] NULL,
	[arriveTime] [datetime2](7) NULL,
	[PointOfOrigin] [varbinary](500) NULL,
	[Destinstion] [varchar](500) NULL,
	[jobID] [varchar](50) NULL,
	[contractorID] [int] NULL,
	[sabhaulerID] [int] NULL,
	[driverID] [int] NULL,
	[truckDriverID] [int] NULL,
	[PayRate] [int] NULL,
	[startTime] [datetime2](7) NULL,
	[finishTime] [datetime2](7) NULL,
	[deductTime] [datetime2](7) NULL,
	[netOverallTime] [datetime2](7) NULL,
	[driverSignature] [varchar](500) NULL,
	[formanSignature] [varchar](500) NULL,
	[note] [varchar](500) NULL,
	[summary] [varchar](500) NULL,
	[invoiceFile] [varchar](100) NULL,
	[deleted] [int] NULL,
 CONSTRAINT [PK_tblJobInfo] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[tblJobInfo] ADD  CONSTRAINT [DF_tblJobInfo_deleted]  DEFAULT ((0)) FOR [deleted]
GO

