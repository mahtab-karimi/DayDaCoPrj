USE [dbWebTag]
GO

/****** Object:  Table [dbo].[tblBroker]    Script Date: 10/19/2019 10:42:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tblBroker](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](500) NULL,
	[phoneNo] [varbinary](50) NULL,
	[email] [varbinary](100) NULL,
	[deleted] [int] NULL,
 CONSTRAINT [PK_tblBroker] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[tblBroker] ADD  CONSTRAINT [DF_tblBroker_deleted]  DEFAULT ((0)) FOR [deleted]
GO

