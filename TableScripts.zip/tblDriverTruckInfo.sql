USE [dbWebTag]
GO

/****** Object:  Table [dbo].[tblDriverTruckInfo]    Script Date: 10/19/2019 10:42:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tblDriverTruckInfo](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[driverID] [int] NULL,
	[truckID] [int] NULL,
	[NumberOfAxles] [int] NULL,
	[LicensePlateNo] [varchar](50) NULL,
	[truckNo] [varbinary](50) NULL,
	[deleted] [int] NULL,
 CONSTRAINT [PK_tblDriverTruckInfo] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[tblDriverTruckInfo] ADD  CONSTRAINT [DF_tblDriverTruckInfo_deleted]  DEFAULT ((0)) FOR [deleted]
GO

