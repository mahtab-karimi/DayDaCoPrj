USE [dbWebTag]
GO

/****** Object:  Table [dbo].[tblJobDetails]    Script Date: 10/19/2019 10:43:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tblJobDetails](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[jobID] [int] NULL,
	[loadTypeID] [int] NULL,
	[arriveTime] [datetime2](7) NULL,
	[departTime] [datetime2](7) NULL,
	[weight] [int] NULL,
	[material] [varchar](50) NULL,
	[standbyTime] [datetime2](7) NULL,
	[tolls] [int] NULL,
 CONSTRAINT [PK_tblJobDetails] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

